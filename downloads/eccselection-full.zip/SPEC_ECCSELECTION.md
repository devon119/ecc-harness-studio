# ECCSELECTION 專案 SA/SD 系統規格書

| 項目 | 內容 |
| :--- | :--- |
| **專案名稱** | `ECCSELECTION` |
| **工作區路徑** | `D:\T01_GIT\ECCSELECTION` |
| **目標環境** | .NET 10 SDK (`10.0.100`) / ASP.NET Core MVC / SQLite / EF Core / xUnit |
| **文件狀態** | Gate 1 + v1.4 收斂推薦、Gemini 精選與運作說明規格 |
| **變更風險等級** | **中風險**（新建獨立 MVC 專案與 SQLite 結構，無既有資料破壞風險；涉及外部 GitHub API 整合與持久化結構設計） |

---

## 一、專案目標與範圍界定

### 1.1 背景與痛點
`affaan-m/ECC`（Everything Claude Code）包含大量 `agents`、`skills`、`rules` 與 `commands` Markdown 元件。開發團隊在啟動新專案或建立 AI 輔助開發規範（Harness）時，難以針對特定的專案型態、架構風格、技術棧與 SDLC 角色快速篩選出最精準的元件組合。

### 1.2 核心目標
建立一個本地可運行、可離線查詢、可定期與 GitHub 上游同步的 **ECC 元件知識庫與智慧選型系統**：
1. **GitHub 增量同步引擎**：透過 GitHub Git Trees API 偵測 `agents`、`skills`、`rules`、`commands` 異動，僅針對新增或 `Sha` 變更的檔案下載 Raw 內容並解析入庫。
2. **SQLite 知識庫管理**：持久化儲存 ECC 元件中繼資料、中英文摘要、SDLC 角色、技術棧與架構標籤，支援瀏覽、搜尋與人工微調。
3. **互動式組建問券（Harness Wizard）**：透過確定性權重與標籤配對演算法（不依賴即時 LLM 呼叫），按 SDLC 角色產出可解釋的推薦清單，並支援匯出 Markdown 文件。

---

## 二、系統架構與分層設計

### 2.1 整體架構圖

```mermaid
flowchart TD
    User["使用者瀏覽器"] --> MVC["ASP.NET Core MVC Controllers"]
    MVC --> WizardSvc["IRecommendationService (確定性配對引擎)"]
    MVC --> ExportSvc["IMarkdownExportService (Markdown 匯出)"]
    MVC --> CatalogSvc["IEccCatalogService (知識庫查詢與編輯)"]
    MVC --> SyncSvc["IGitHubSyncService (GitHub 增量同步引擎)"]

    SyncSvc --> GitHubAPI["GitHub Trees & Raw API"]
    SyncSvc --> ParserSvc["IEccParserService (YAML Frontmatter + 規則推斷)"]
    SyncSvc --> LlmSvc["ILlmEnrichmentService (可選：繁中摘要增強)"]

    WizardSvc --> DbContext["AppDbContext (EF Core + SQLite)"]
    CatalogSvc --> DbContext
    SyncSvc --> DbContext
```

### 2.2 方案目錄結構（Solution Layout）

```text
D:\T01_GIT\ECCSELECTION\
├── ECCSELECTION.sln
├── README.md
├── src\
│   └── ECCSELECTION.Web\
│       ├── ECCSELECTION.Web.csproj
│       ├── Program.cs
│       ├── appsettings.json
│       ├── appsettings.Development.json
│       ├── Data\
│       │   └── AppDbContext.cs
│       ├── Models\
│       │   ├── EccComponent.cs
│       │   ├── SyncLog.cs
│       │   └── Enums\
│       │       ├── ComponentType.cs
│       │       └── SyncStatus.cs
│       ├── ViewModels\
│       │   ├── WizardRequestViewModel.cs
│       │   ├── WizardResultViewModel.cs
│       │   ├── EccCatalogFilterViewModel.cs
│       │   ├── EccComponentEditViewModel.cs
│       │   └── SyncDashboardViewModel.cs
│       ├── Services\
│       │   ├── Interfaces\
│       │   │   ├── IGitHubSyncService.cs
│       │   │   ├── IEccParserService.cs
│       │   │   ├── ILlmEnrichmentService.cs
│       │   │   ├── IRecommendationService.cs
│       │   │   ├── IMarkdownExportService.cs
│       │   │   └── IEccCatalogService.cs
│       │   ├── GitHubSyncService.cs
│       │   ├── EccParserService.cs
│       │   ├── LlmEnrichmentService.cs
│       │   ├── RecommendationService.cs
│       │   ├── MarkdownExportService.cs
│       │   └── EccCatalogService.cs
│       ├── Options\
│       │   ├── GitHubSyncOptions.cs
│       │   └── LlmEnrichmentOptions.cs
│       ├── Controllers\
│       │   ├── HomeController.cs
│       │   ├── WizardController.cs
│       │   ├── CatalogController.cs
│       │   └── SyncController.cs
│       └── Views\
│           ├── Shared\
│           ├── Home\
│           ├── Wizard\
│           ├── Catalog\
│           └── Sync\
└── tests\
    └── ECCSELECTION.Tests\
        ├── ECCSELECTION.Tests.csproj
        ├── Services\
        │   ├── EccParserServiceTests.cs
        │   ├── GitHubSyncServiceTests.cs
        │   ├── RecommendationServiceTests.cs
        │   └── MarkdownExportServiceTests.cs
        └── Helpers\
            └── TestDbContextFactory.cs
```

### 2.3 設定檔契約（`appsettings.json`）

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=eccselection.db"
  },
  "GitHubSync": {
    "Owner": "affaan-m",
    "Repo": "ECC",
    "Branch": "main",
    "PersonalAccessToken": ""
  },
  "LlmEnrichment": {
    "Enabled": false,
    "Endpoint": "",
    "ApiKey": "",
    "Model": ""
  }
}
```

> [!NOTE]
> `PersonalAccessToken` 與 `LlmEnrichment.ApiKey` 皆為可選項，建議於開發環境使用 `dotnet user-secrets` 或環境變數覆寫，嚴禁將真實密鑰寫入版本控制。

---

## 三、SQLite 資料庫設計（EF Core）

### 3.1 ER 關聯與資料表定義

```mermaid
erDiagram
    EccComponents {
        int Id PK
        string ComponentType
        string Name
        string Path UK
        string Sha
        string RawUrl
        string HtmlUrl
        string DescriptionEn
        string SummaryZh
        string SdlcRoles
        string TechStacks
        string ArchStyles
        string UsageGuide
        datetime LastSyncedAt
        bool IsActive
        bool IsManuallyEdited
    }

    SyncLogs {
        int Id PK
        datetime StartedAt
        datetime CompletedAt
        string Status
        int TotalFound
        int AddedCount
        int UpdatedCount
        int RemovedCount
        string ErrorMessage
    }
```

### 3.2 `EccComponents` 欄位與約束

| 欄位名稱 | C# 型別 | SQLite 型別 | 約束 / 說明 |
| :--- | :--- | :--- | :--- |
| `Id` | `int` | `INTEGER` | Primary Key, AutoIncrement |
| `ComponentType` | `ComponentType` (Enum -> String) | `TEXT` | 必填：`Agent` / `Skill` / `Rule` / `Command` |
| `Name` | `string` | `TEXT` | 必填，最長 200 字元 |
| `Path` | `string` | `TEXT` | 必填，**Unique Index**，Repo 內相對路徑（如 `agents/architect.md`） |
| `Sha` | `string` | `TEXT` | 必填，最長 64 字元，Git Blob SHA |
| `RawUrl` | `string` | `TEXT` | 必填，`https://raw.githubusercontent.com/affaan-m/ECC/main/{Path}` |
| `HtmlUrl` | `string` | `TEXT` | 必填，`https://github.com/affaan-m/ECC/blob/main/{Path}` |
| `DescriptionEn` | `string` | `TEXT` | 可為空字串，來自 YAML Frontmatter 或首段摘要 |
| `SummaryZh` | `string` | `TEXT` | 可為空字串，規則生成或 LLM 增強之繁體中文摘要 |
| `SdlcRoles` | `string` | `TEXT` | 以標準化逗號分隔或 JSON 陣列儲存，如 `SA,SD` |
| `TechStacks` | `string` | `TEXT` | 標準化小寫 Slug 清單，如 `dotnet,react,common` |
| `ArchStyles` | `string` | `TEXT` | 標準化小寫 Slug 清單，如 `mvc,clean,mvvm,general` |
| `UsageGuide` | `string` | `TEXT` | 觸發時機與使用方式摘要 |
| `LastSyncedAt` | `DateTime` | `TEXT` (UTC) | 最後一次同步時間 |
| `IsActive` | `bool` | `INTEGER` | 預設 `true`；若上游已刪除則軟刪除為 `false` |
| `IsManuallyEdited` | `bool` | `INTEGER` | 預設 `false`；若使用者曾手動編輯中文摘要/標籤，同步更新時保留人工欄位 |

> [!TIP]
> 多值欄位（`SdlcRoles`, `TechStacks`, `ArchStyles`）在 Domain Model 中以標準化逗號分隔字串儲存，並提供輔助方法轉為 `IReadOnlyList<string>` 進行精確 Token 比對（避免 `java` 誤匹配 `javascript`）。

### 3.3 `SyncLogs` 欄位與約束

| 欄位名稱 | C# 型別 | SQLite 型別 | 約束 / 說明 |
| :--- | :--- | :--- | :--- |
| `Id` | `int` | `INTEGER` | Primary Key, AutoIncrement |
| `StartedAt` | `DateTime` | `TEXT` (UTC) | 同步開始時間 |
| `CompletedAt` | `DateTime?` | `TEXT` (UTC) | 同步結束時間 |
| `Status` | `SyncStatus` (Enum -> String) | `TEXT` | `Running` / `Success` / `PartialSuccess` / `Failed` |
| `TotalFound` | `int` | `INTEGER` | 本次 Tree API 篩選符合規則的檔案總數 |
| `AddedCount` | `int` | `INTEGER` | 新增筆數 |
| `UpdatedCount` | `int` | `INTEGER` | `Sha` 異動更新筆數 |
| `RemovedCount` | `int` | `INTEGER` | 上游移除（設為 `IsActive = false`）筆數 |
| `ErrorMessage` | `string?` | `TEXT` | 錯誤或部分失敗摘要 |

---

## 四、GitHub 同步引擎與解析規則

### 4.1 同步流程與路徑過濾契約

1. **呼叫 GitHub Trees API**：
   - `GET https://api.github.com/repos/{Owner}/{Repo}/git/trees/{Branch}?recursive=1`
   - 必帶 Header：`User-Agent: ECCSELECTION-Sync/1.0`
   - 若 `PersonalAccessToken` 非空，帶入 `Authorization: Bearer {Token}`，避免未驗證 60 req/hr 限流。
2. **Tree Item 過濾規則**（僅處理 `type == "blob"`）：
   - `^agents/[^/]+\.md$` → `ComponentType.Agent`
   - `^skills/[^/]+/SKILL\.md$` → `ComponentType.Skill`
   - `^rules/[^/]+/[^/]+\.md$` → `ComponentType.Rule`
   - `^commands/[^/]+\.md$` → `ComponentType.Command`
   - 排除 `README.md`、`CONTRIBUTING.md` 等非元件檔案。

### 4.2 SHA 增量比對演算法

```mermaid
flowchart LR
    A["取得 GitHub Tree Blobs"] --> B{"DB 是否存在該 Path?"}
    B -- 否 --> C["下載 Raw 內容 -> 解析 -> Insert (AddedCount++)"]
    B -- 是 --> D{"DB.Sha == Blob.Sha ?"}
    D -- 是 --> E["僅更新 LastSyncedAt 與 IsActive=true"]
    D -- 否 --> F["下載 Raw 內容 -> 解析 -> Update (UpdatedCount++)"]
    F --> G{"IsManuallyEdited == true ?"}
    G -- 是 --> H["僅更新 Sha/Raw/DescriptionEn，保留 SummaryZh 與人工標籤"]
    G -- 否 --> I["全面更新解析欄位與可選 LLM 摘要"]
    A --> J["比對 DB 中 IsActive=true 但未出現在此次 Tree 的 Path"]
    J --> K["設為 IsActive=false (RemovedCount++)"]
```

### 4.3 Markdown 與 YAML Frontmatter 解析規則（`EccParserService`）

1. **YAML Frontmatter 擷取**：
   - 若檔案以 `---` 開頭，解析至下一個 `---` 之間的 Key-Value（可使用 `YamlDotNet` 或嚴謹的行解析器）：
     - `name` → 若無則退回使用檔名（Skill 則使用上層資料夾名稱，如 `skills/tdd-workflow/SKILL.md` → `tdd-workflow`）。
     - `description` → 寫入 `DescriptionEn`；若 Frontmatter 無 `description`，擷取正文第一個非標題段落（最長 300 字元）。
2. **使用方式與觸發時機（`UsageGuide`）擷取**：
   - 優先擷取 Markdown 中標題包含 `When to Use`、`Usage`、`Trigger`、`How to Use` 的區段摘要；若為 `Command`，自動標註 `/command-name` 觸發格式。
3. **確定性標籤推斷規則**：
   - **技術棧（`TechStacks`）**：
     - 路徑規則：`rules/common/*` → `common`；`rules/python/*` → `python`；`rules/golang/*` → `go`；`rules/typescript/*` → `react,vue,typescript`；`rules/java/*` 或 `springboot` → `java`；`rules/kotlin/*` → `kotlin`；`rules/dotnet/*` 或 `csharp` → `dotnet`。
     - 關鍵字規則（比對 `Name` + `DescriptionEn` + 正文前 1500 字）：偵測 `postgres`/`postgresql` → `postgres`、`mysql` → `mysql`、`sqlite` → `sqlite`、`sql server`/`mssql` → `sqlserver`、`react` → `react`、`vue` → `vue`、`android`/`kotlin` → `kotlin`、`dotnet`/`.net`/`c#`/`ef core` → `dotnet`、`python`/`django`/`fastapi` → `python`、`golang`/`go` → `go`、`java`/`spring` → `java`。若皆無特定語言，標記 `common`。
   - **SDLC 角色（`SdlcRoles`）**：
     - 關鍵字映射表：
       - `SA`：`architect`, `plan`, `requirements`, `spec`, `design`, `system`, `prd`
       - `SD`：`architect`, `api-design`, `schema`, `database-design`, `pattern`, `clean`, `mvc`, `mvvm`
       - `PG_FE`：`frontend`, `react`, `vue`, `ui`, `css`, `accessibility`, `e2e`
       - `PG_BE`：`backend`, `api`, `dotnet`, `go`, `python`, `java`, `auth`, `security`, `service`
       - `PG_DB`：`database`, `sql`, `postgres`, `mysql`, `sqlite`, `migration`, `query`, `ef core`
       - `PG_TEST`：`tdd`, `test`, `unit`, `coverage`, `mock`, `xunit`, `pytest`
       - `QA`：`review`, `code-review`, `security-review`, `verify`, `qa`, `e2e`, `audit`
     - 若無法匹配特定角色，預設依類型給予通用角色（如 `Rule` 且含 `common` → `SA,SD,PG_FE,PG_BE,PG_DB,PG_TEST,QA`）。
   - **架構風格（`ArchStyles`）**：
     - 偵測 `mvc`、`clean`、`mvvm`；若無明確指定則標記 `general`。
4. **中文摘要（`SummaryZh`）預設生成**：
   - 若未啟用 LLM，系統依 `ComponentType`、`Name`、`SdlcRoles` 與 `DescriptionEn` 組合產生結構化繁中說明（例如：`[Agent] 架構規劃師（適用：SA, SD）— 負責系統架構設計與技術決策。`），確保知識庫在無 LLM Key 時仍具備完整可讀性。

### 4.4 可選 LLM 增強服務（`LlmEnrichmentService`）

- **非阻塞原則**：`LlmEnrichment.Enabled == false` 或 `ApiKey` 為空時，直接返回 `null`，同步流程零延遲通過。
- **降級保護**：若呼叫外部 OpenAI-compatible Endpoint 發生逾時或錯誤（單筆 Timeout 建議 15 秒），記錄 Warning 並保留規則式摘要，絕不導致整體同步失敗。

---

## 五、互動式組建問券與確定性配對邏輯

### 5.1 問券輸入規格（`WizardRequestViewModel`）與連動相容性規則（`WizardCompatibility`）

| 欄位 | 型別 | 選項值 |
| :--- | :--- | :--- |
| `ProjectType` | `string` | `Web`, `Mobile`, `API`, `Fullstack`, `Game`（遊戲開發 / Roblox / Unity / Godot） |
| `ProjectLifecycle` | `string` | `Greenfield`（新專案從零建置） / `Brownfield`（舊專案導入與重構） |
| `ArchStyle` | `string` | `MVC`, `Clean`, `MVVM`, `ECS`（遊戲物件 / Entity-Component-System） |
| `TechStacks` | `List<string>` | `dotnet`, `kotlin`, `react`, `vue`, `python`, `go`, `java`, `luau`（Roblox Luau / Lua）, `godot`（Godot / GDScript）, `cpp`, `sqlserver`, `sqlite`, `postgres`, `mysql` |
| `SdlcRoles` | `List<string>` | `SA`, `SD`, `PG_FE`, `PG_BE`, `PG_DB`, `PG_TEST`, `QA` |
| `Mode` | `string` | `Compact`（精簡核心） / `Comprehensive`（完整參考） |

為避免產出不合理之技術組合（例如 `Web` 搭配 `Kotlin / Android`、或 `API` 搭配 `PG-前端` / `React`），系統由 `WizardCompatibility` 作為前後端單一真理來源（Single Source of Truth），強制執行以下專案型態連動相容性矩陣：

| 專案型態 | 適用架構風格 (`Default`) | 適用技術棧與資料庫 (`Default`) | 適用 SDLC 角色 |
| :--- | :--- | :--- | :--- |
| `Web` | `MVC` *(預設)*, `Clean` | `dotnet` *(預設)*, `react`, `vue`, `python`, `go`, `java`, `sqlserver`, `sqlite`, `postgres`, `mysql`（排除 `kotlin`, `luau`, `godot`, `cpp`） | `SA`, `SD`, `PG_FE`, `PG_BE`, `PG_DB`, `PG_TEST`, `QA` |
| `Mobile` | `MVVM` *(預設)*, `Clean` | `kotlin` *(預設)*, `sqlite` *(預設)*（排除 Web/後端語言與遠端伺服器 DB） | `SA`, `SD`, `PG_FE`, `PG_DB`, `PG_TEST`, `QA`（排除 `PG_BE`） |
| `API` | `Clean` *(預設)*, `MVC` | `dotnet` *(預設)*, `python`, `go`, `java`, `sqlserver`, `sqlite`, `postgres`, `mysql`（排除 `kotlin`, `react`, `vue`, `luau`, `godot`） | `SA`, `SD`, `PG_BE`, `PG_DB`, `PG_TEST`, `QA`（排除 `PG_FE`） |
| `Fullstack` | `Clean` *(預設)*, `MVC` | `dotnet` *(預設)*, `react` *(預設)*, `vue`, `python`, `go`, `java`, `sqlserver`, `sqlite`, `postgres`, `mysql`（排除 `kotlin`, `luau`, `godot`, `cpp`） | `SA`, `SD`, `PG_FE`, `PG_BE`, `PG_DB`, `PG_TEST`, `QA` |
| `Game` | `ECS` *(預設)*, `Clean`, `MVC` | `luau` *(預設)*, `godot`, `dotnet`, `cpp`, `sqlite` | `SA`, `SD`, `PG_FE`, `PG_BE`, `PG_DB`, `PG_TEST`, `QA` |

- **前端互動防呆**：切換 `ProjectType` 時，不適用之架構風格、技術棧與角色選項會即時停用（`disabled` + 灰階標示）並自動取消勾選；若當前架構不適用或技術棧全空，自動切換為該型態預設值。
- **後端強制檢核**：`WizardController` 於 `Recommend` 與 `ExportMarkdown` 執行前皆呼叫 `WizardCompatibility.Validate`，拒絕不合法的跨欄位組合（含 `ProjectLifecycle` 必須為 `Greenfield` 或 `Brownfield`）。

### 5.2 確定性權重配對演算法（`RecommendationService`）與 Agent 配套套組

對所有 `IsActive == true` 的元件，針對使用者勾選的每一個目標 `role` 與 `ProjectLifecycle` 獨立計算適配分數（`Score`）並收集可解釋的 `MatchReasons`：

1. **角色過濾（必要條件）**：
   - 元件的 `SdlcRoles` 必須包含目標 `role`（或同時滿足以下條件之通用規則）。
   - 權重加分：`+40` 分，理由：`「符合角色定位：{RoleDisplayName}」`。
2. **技術棧匹配**：
   - 元件 `TechStacks` 與使用者選擇的 `TechStacks` 有交集（每命中一個 `+25` 分，上限 `+50` 分），理由：`「命中技術棧：{MatchedStacks}」`。
   - 若元件包含 `common`（通用規範）：`+15` 分，理由：`「通用工程規範（適用跨技術棧）」`。
   - **衝突排除**：若元件明確屬於某特定語言（例如僅含 `python`，不含 `common`），而使用者完全未選 `python`，則該元件**直接排除**（避免將 Python 規範推薦給純 .NET 或 Roblox 專案）。
3. **架構風格、專案型態與導入階段（`ProjectLifecycle`）匹配**：
   - 元件 `ArchStyles` 命中使用者 `ArchStyle`：`+15` 分，理由：`「符合架構風格：{ArchStyle}」`；若為 `general`：`+5` 分。
   - 專案型態輔助加權：如 `Mobile` 對 `kotlin` / `mvvm` 加 `+10` 分；`API` 對 `PG_BE` / `PG_DB` 相關元件加 `+10` 分；`Game` 對 `luau` / `godot` / `gdscript` / `gan-*` / `cpp` 加 `+15` 分。
   - 導入階段（`ProjectLifecycle`）加權：
     - `Greenfield`（新專案）：對架構規劃、TDD 起手、規格與生成類元件（如 `architect`, `planner`, `tdd-guide`, `gan-planner`, `gan-generator`, `database-reviewer`）加 `+20` 分。
     - `Brownfield`（舊專案導入）：對程式碼探索、規格反推、重構清理、既有測試與品質審計類元件（如 `code-explorer`, `spec-miner`, `refactor-cleaner`, `silent-failure-hunter`, `harness-optimizer`, `code-reviewer`, `security-reviewer`, `e2e-runner`）加 `+20` 分。
4. **以 Agent 為核心的配套套組（`HarnessSuiteViewModel`）**：
   - 系統從推薦出的核心 **Agent** 出發，依共享 `SdlcRoles`、共享 `TechStacks`、領域關鍵字親和度與 `ProjectLifecycle` 一致性，自動為每個 Agent 配對最適合的 **Skill**、**Rule** 與 **Command**，組成一整套可勾選的 Harness 套組。
   - 結果頁提供套組級與單一檔案級勾選框（Checkbox），預設全選，使用者可自由增減。
5. **精簡模式（`Compact` vs `Comprehensive`）**：
   - 排序依據：`Score` 降冪 → `ComponentType` 優先序（`Agent` → `Rule` → `Skill` → `Command`）→ `Name` 升冪。
   - `Compact`（精簡核心）：每個 SDLC 角色僅取分數最高之前 **3~5** 項（且 `Score >= 50`），每個 Agent 套組嚴格收斂配對 **最多 2 Skill、2 Rule、1 Command**（且 `pairScore >= 50`，必須命中技術棧、領域關鍵字或需求關鍵字，避免純通用項目湊數）。
   - `Comprehensive`（完整參考）：每個 SDLC 角色取前 **10~15** 項（`Score >= 40`），每個 Agent 套組最多 **3 Skill、3 Rule、2 Command**。
   - **候選延伸清單（`AdditionalCandidates`）**：未進入預設精選核心但分數達標之元件，保留於結果頁「其他候選項目（可手動加勾）」摺疊區塊，預設不勾選，由使用者自由加選。

### 5.3 推薦結果頁面、勾選與真實檔案 ZIP 下載（`HarnessBundleService`）

- 推薦結果頁面同時呈現 **「以 Agent 為核心的配套套組（預設檢視）」** 與 **「依 SDLC 角色分組清單」**，每個元件皆附有勾選框。
- 使用者勾選完成後，點擊上方 **「下載勾選的 Harness 套件 (.zip)」**（`POST /Wizard/DownloadBundle`）：
  - 後端依勾選的 `SelectedComponentIds`（去重）讀取資料庫中之 `RawUrl` 與 `LocalSuggestedPath`。
  - 透過 `HttpClient` 從 GitHub Raw URL 下載實際檔案內容，並依建議路徑（如 `.claude/agents/architect.md`、`.claude/skills/tdd-workflow/SKILL.md`、`.claude/rules/...`、`.claude/commands/...`）打包為 `ecc-harness-bundle.zip` 供使用者直接解壓縮至專案根目錄使用。
  - 若個別檔案下載失敗，記錄日誌並在 ZIP 內附註 `DOWNLOAD_ERRORS.txt`，不靜默吞錯。
- 保留「匯出推薦摘要 (.md)」作為輔助文件匯出。

### 5.4 v1.3 需求文件解析、專案參數與防堵卡點（Guardrails）組建

1. **需求用途與文件解析（`IRequirementAnalyzerService` / `RequirementAnalyzerService`）**：
   - 使用者可於 `/Wizard` 填寫 `ProjectPurpose`（用途與需求說明文字）並上傳需求文件 `RequirementDocument`（支援 `.md`, `.txt`, `.json`, `.yaml`, `.yml`, `.csv`, `.xml`，單檔上限 2 MB，拒絕未允許副檔名與二進位檔）。
   - `RequirementAnalyzerService` 採**混合式深度分析（LLM 優先 + 確定性非阻塞降級）**：
     - 當 `LlmEnrichment.Enabled == true` 且設定 `Endpoint` 與 `ApiKey` 時，呼叫 OpenAI-compatible API 進行語意深度分析，推斷專案型態、生命週期、架構風格、技術棧、SDLC 角色、建議專案名稱、擴充英文檢索關鍵詞，以及**自動產出工程組建參數**（`TargetEnvironment`、`BuildCommand`、`FormatCommand`、`TestCommand`、`SecurityScanCommand`），並經由 `WizardCompatibility` 強制校驗合法性。
     - 若未設定 LLM 或呼叫逾時/失敗（15 秒 Timeout），自動非阻塞降級為確定性規則與關鍵字解析（依技術棧自動推斷對應環境與建置/測試指令），並於 `AnalysisSource` 標註實際使用模式。
   - `POST /Wizard/AnalyzeRequirements`（AJAX/表單輔助）或於 `Recommend` 提交時自動解析並將 `ExtractedKeywords` 納入 `RecommendationService` 權重計算：
     - 元件的 `Name`、`DescriptionEn`、`SummaryZh`、`UsageGuide`、`TechStacks` 命中需求關鍵字時，每個關鍵字加 `+8` 分（上限 `+32` 分），並於 `MatchReasons` 標註 `「命中需求關鍵字：{Keywords}」`。

2. **專案組建參數與防堵卡點選項（`HarnessAssemblyOptionsViewModel`）**：
   - 使用者僅需填寫直覺的基本資訊（`ProjectName`、`SpecFilePath`、`DevServerUrl`、`TargetPlatform`）與防堵卡點開關；其餘工程指令（`TargetEnvironment`、`BuildCommand`、`FormatCommand`、`TestCommand`、`SecurityScanCommand`、`ScopeGuardNote`、`ProtectedPaths`）由系統／LLM 依需求與技術棧**自動產出**，並收納於可收合的「進階工程參數」區塊供進階使用者檢視或微調：
     - `ProjectName`（專案名稱，預設 `MyProject`）
     - `TargetEnvironment`（目標環境說明，如 `.NET 10 / ASP.NET Core MVC`）
     - `SpecFilePath`（規格書路徑，預設 `SPEC.md`）
     - `BuildCommand`（建置指令，依專案技術棧提供合理預設，如 `dotnet build -warnaserror`）
     - `FormatCommand`（格式檢查指令，如 `dotnet format --verify-no-changes --no-restore`）
     - `TestCommand`（測試指令，如 `dotnet test --no-build --verbosity normal`）
     - `SecurityScanCommand`（安全掃描指令，預設 `npx --yes ecc-agentshield scan --path . --format text`）
     - `DevServerUrl`（實機驗證網址，可選，如 `http://localhost:5109`）
     - `ScopeGuardNote`（架構邊界與異動範圍限制說明，預設 `僅限專案原始碼與測試目錄，禁止未授權修改部署與憑證設定`）
     - `ProtectedPaths`（受保護／禁止 AI 直接覆寫的敏感路徑清單，預設 `.env*,**/*.pem,**/*.key,**/secrets.*,appsettings.Production.json`）
     - `TargetPlatform`（目標 AI Harness 平台：`All` / `Antigravity` / `ClaudeCode`，預設 `All`）
   - **防堵卡點（Guardrail Gates）開關**（預設全數啟用）：
     - `RequireSpecFirst`：未更新 `{SpecFilePath}` 前禁止實作核心功能。
     - `RequireTestsBeforeDone`：強制 TDD / 單元測試與品質閘門全綠，未通過禁止宣告完成。
     - `RequireEvidenceOutput`：強制證據輸出契約（必須附上各項指令實測結果，禁止口頭宣稱已檢查）。
     - `IncludeGitPreCommitHook`：於 ZIP 產出 `.githooks/pre-commit` 與 `scripts/install-hooks.ps1` / `scripts/install-hooks.sh`，在 `git commit` 前強制攔截格式/建置/密鑰違規。
     - `IncludeIdeAutoRules`：於 ZIP 產出自動載入的根目錄規範 `AGENTS.md`、`CLAUDE.md`、`.agents/rules/workflow-guardrails.md`、`.claude/settings.json`（含 Hook 防堵設定）與可執行品質閘門 `scripts/quality-gate.ps1` / `scripts/quality-gate.sh`。

3. **防堵卡點組建輸出契約（`HarnessBundleService.BuildBundleZipAsync`）**：
   - 除了原本從 GitHub 下載的 `.claude/{agents,skills,rules,commands}/...`（當 `TargetPlatform` 為 `All` 或 `Antigravity` 時亦同步鏡像至 `.agents/` 或 `.ecc/`），若啟用防堵卡點與專案參數，ZIP 套件必須直接組建並包含：
     - `AGENTS.md` 與 `CLAUDE.md`（嵌入專案參數、已選元件清單、不可繞過的 4 道 HARD GATES 與證據輸出契約）。
     - `.agents/rules/workflow-guardrails.md`（供 IDE/Agent 自動載入的工作流強制規則）。
     - `.claude/settings.json`（Claude Code 原生 `permissions.deny` 敏感路徑阻擋規則 + `PreToolUse` / `Stop` Hooks 防堵設定）。
     - `scripts/quality-gate.ps1` 與 `scripts/quality-gate.sh`（依使用者填入的 `BuildCommand`、`FormatCommand`、`TestCommand`、`SecurityScanCommand` 組建，任一步驟失敗即非零結束碼阻擋）。
     - `.githooks/pre-commit`、`scripts/install-hooks.ps1`、`scripts/install-hooks.sh`（Git 提交前卡點）。
     - `HARNESS_PLAYBOOK.md` & `README_HARNESS.md`（客製化 Harness 運作說明書：SDLC 工作動線、角色/指令觸發時機、自動生效規範與防堵卡點說明）。

### 5.5 v1.4 Gemini 精挑細選（API 自動模式 ＋ Chrome 網頁版接力模式）

1. **兩階段漏斗架構（`IGeminiCurationService` / `GeminiCurationService`）**：
   - **Stage 1**：`RecommendationService` 確定性初篩出相容的 Top 35 候選元件。
   - **Stage 2A（Gemini API 背景自動精選）**：支援原生 Gemini REST API（`https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`）與 OpenAI-compatible 端點，將需求描述與 Top 35 候選摘要送交 Gemini，回傳精選元件 ID 清單、各元件入選理由、以及客製化 `HarnessPlaybookMarkdown`。若未設定 Key 或失敗，非阻塞降級為確定性收斂結果與規則式 `HARNESS_PLAYBOOK.md`。
   - **Stage 2B（Chrome Gemini 網頁版接力模式）**：因瀏覽器同源政策與 Google 登入隔離，無法從本機或 GitHub 靜態站背景代理呼叫 `gemini.google.com`，系統提供「一鍵複製精選 Prompt 並開啟 `https://gemini.google.com/app`」及「貼回 Gemini JSON 回覆套用」端點（`POST /Wizard/ApplyGeminiCuration`），讓無 API Key 的使用者也能直接使用 Chrome 上已登入的 Gemini 完成精選。
   - **API Key 引導與本機設定**：於 `/Wizard` 提供 Google AI Studio（`https://aistudio.google.com/apikey`）免費取得 Key 之引導步驟，並提供 `POST /Wizard/SaveGeminiKey`（僅寫入本機 `appsettings.Development.json` 或記憶體/本機設定，該檔已列入 `.gitignore` 嚴禁入版控）。

---

## 六、MVC 頁面與控制器規劃

| Controller | Action | 職責說明 |
| :--- | :--- | :--- |
| `HomeController` | `Index` | 系統首頁與統計儀表板（已同步元件數、各類型分布、最近同步狀態、快速進入問券） |
| `WizardController` | `Index` (GET) | 顯示互動式組建問券表單 |
| `WizardController` | `Recommend` (POST) | 執行 `IRecommendationService`，顯示按 SDLC 角色分組的推薦表格 |
| `WizardController` | `ExportMarkdown` (POST) | 產出並下載 `ecc-harness-recommendation.md`（`text/markdown`） |
| `CatalogController` | `Index` (GET) | 知識庫瀏覽、關鍵字搜尋、依 `ComponentType` / `SdlcRole` / `TechStack` 篩選 |
| `CatalogController` | `Details` / `Edit` (GET/POST) | 檢視元件完整資訊與編輯 `SummaryZh`、`SdlcRoles`、`TechStacks`、`ArchStyles`（更新時設定 `IsManuallyEdited = true`） |
| `SyncController` | `Index` (GET) | 顯示 `SyncLogs` 歷史紀錄與設定狀態（Token 是否已設定、LLM 是否啟用） |
| `SyncController` | `Trigger` (POST) | 手動觸發 `IGitHubSyncService.SyncAsync()` 並導回結果通知 |

---

## 七、Scope Guard 清單（嚴格邊界控制）

| 類別 | 允許範圍 | 禁止範圍 |
| :--- | :--- | :--- |
| **檔案建立與修改** | 僅限 `D:\T01_GIT\ECCSELECTION\` 目錄內之 `.sln`、`ECCSELECTION.Web`、`ECCSELECTION.Tests`、`README.md` 與 `.gitignore` | 嚴禁修改 `D:\T01_GIT\ECCSELECTION\` 以外的任何專案檔案或全域系統設定 |
| **資料庫** | 專案內本地 SQLite 檔案 `eccselection.db`（EF Core Code-First / `EnsureCreated` 或 `Migrate`） | 不得連線或修改外部資料庫 |
| **外部網路** | 僅限 `api.github.com`、`raw.githubusercontent.com` 及使用者顯式設定之 LLM Endpoint | 嚴禁於單元測試中發起真實外部 HTTP 請求（測試須使用 Mock `HttpMessageHandler`） |

---

## 八、測試防線與驗收標準

### 8.1 單元測試計畫（`ECCSELECTION.Tests`）
1. **`EccParserServiceTests`**：
   - 驗證含 YAML Frontmatter 與無 Frontmatter 的 Markdown 解析。
   - 驗證 `agents`、`skills`、`rules`、`commands` 的名稱與路徑推斷。
   - 驗證技術棧、SDLC 角色、架構風格推斷準確性。
2. **`GitHubSyncServiceTests`**：
   - 使用假 `HttpMessageHandler` 模擬 GitHub Tree API 與 Raw 下載：
     - 初次同步：正確新增（`AddedCount`）。
     - 二次同步（`Sha` 未變）：不重複下載 Raw、`UpdatedCount == 0`。
     - `Sha` 變更：僅下載變更檔案，且若 `IsManuallyEdited == true` 保留人工中文摘要。
     - 上游移除檔案：標記 `IsActive = false`、`RemovedCount == 1`。
3. **`RecommendationServiceTests`**：
   - 驗證「.NET + MVC + SA/PG_BE/PG_DB」問券條件能命中相關元件且排除純 Python/Go 專屬元件。
   - 驗證 `Compact` 與 `Comprehensive` 模式的數量與分數門檻差異。
   - 驗證 `MatchReasons` 非空且準確反映命中條件。
4. **`MarkdownExportServiceTests`**：
   - 驗證匯出 Markdown 包含問券條件摘要、SDLC 角色分組標題、標準表格欄位與 Raw URL。

### 8.2 端到端驗收標準（Gate 2 核對基準）
1. **編譯與測試**：於 `D:\T01_GIT\ECCSELECTION` 執行 `dotnet build` 與 `dotnet test`，結果為 **0 錯誤、全數測試通過**。
2. **真實 GitHub 同步驗證**：啟動 Web 專案並觸發同步，成功從 `affaan-m/ECC` 寫入 `EccComponents` 與 `SyncLogs`（`Status == Success`、`TotalFound > 0`），且二次同步時 `AddedCount == 0`、`UpdatedCount == 0`。
3. **問券與匯出驗證**：操作 Harness Wizard 提交問券，成功產出按 SDLC 角色分組的推薦表格，並可下載有效之 `.md` 推薦清單。
4. **知識庫管理驗證**：於 `/Catalog` 可依類型、角色、技術棧篩選，並可編輯儲存元件中文摘要。
