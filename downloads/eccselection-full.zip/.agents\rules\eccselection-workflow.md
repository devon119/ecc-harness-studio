---
trigger: always_on
---
# ECCSELECTION Workspace Rules & .ecc Workflow

在 `D:\T01_GIT\ECCSELECTION` 進行任何開發任務時，必須遵循 `.ecc/rules/project/eccselection-mvc.md` 與 `AGENTS.md` 定義之流程：

1. **規格先行**：功能或規則異動先更新 `SPEC_ECCSELECTION.md`。
2. **MVC 分層**：商業邏輯放 `Services/`，Controller 僅處理 HTTP 驗證（含 `[ValidateAntiForgeryToken]`）與 ViewModel 映射。
3. **嚴禁靜默吞錯**：禁止空 `catch`，外部 HTTP 失敗須記錄並寫入 `SyncLogs.ErrorMessage`。
4. **強制品質閘門與證據回報**：修改完成後，**必須執行** `powershell -ExecutionPolicy Bypass -File scripts/quality-gate.ps1`（涵蓋 `dotnet build -warnaserror`、`dotnet format --verify-no-changes`、`dotnet test` 含覆蓋率、`npx ecc-agentshield scan`），並在回覆中逐項附上 4 項實測結果；若有前端 `Views/` / `Controllers/` / JS 異動，須於 `http://localhost:5109` 實機驗證後再更新 `DEVELOPMENT_STATUS.md`。未跑完腳本前禁止宣告完成。
