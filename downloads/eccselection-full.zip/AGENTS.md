# ECCSELECTION — 專案開發規範與工作流程（Antigravity 自動載入）

本工作區已建立專屬 ECC Harness（位於 `.ecc/`）。所有在此專案進行的需求變更、程式修改與審查，必須遵守以下規範與流程：

## 1. 最高專案規範（來自 `.ecc/rules/project/eccselection-mvc.md`）
- **方案與技術棧**：`ECCSELECTION.slnx`、`src/ECCSELECTION.Web`（ASP.NET Core MVC `.NET 10`, EF Core + SQLite）、`tests/ECCSELECTION.Tests`（xUnit + SQLite `:memory:`）。嚴禁未經同意改為 SPA 前後端分離或替換 ORM。
- **分層紀律**：Controller 僅負責 HTTP 驗證與 ViewModel 映射；商業邏輯與共用規則必須放在 `Services/`。
- **核心資料契約**：
  - `EccComponents.Path` 為唯一鍵、`Sha` 為變更比對依據。
  - `IsManuallyEdited == true` 之人工欄位在同步時不得覆蓋。
  - 未設定 `LlmEnrichment:ApiKey` 時必須非阻塞降級為規則式分類。
  - 嚴禁空的 `catch` 區塊；外部 HTTP 失敗必須記錄日誌並寫入 `SyncLogs.ErrorMessage`。
  - 問券推薦（`RecommendationService`）維持確定性初篩與收斂規則，並支援可選 Gemini LLM 精選層（未設定 `LlmEnrichment:ApiKey` 時非阻塞降級為確定性收斂推薦）。

## 2. 標準開發與審查流程（對應 `.ecc/commands/`）
1. **SA / SD 先行（`plan`）**：任何功能或規則變更，先更新 `SPEC_ECCSELECTION.md` 規格後再實作。
2. **TDD 與測試覆蓋（`tdd-guide` / `test-coverage`）**：新增或修改邏輯必須於 `tests/ECCSELECTION.Tests/` 補齊對應 xUnit 單元測試。
3. **程式碼與安全審查（`code-review` / `csharp-reviewer` / `security-scan`）**：檢查輸入驗證、`[ValidateAntiForgeryToken]`、無空 `catch`、無硬編碼密鑰、方法長度與命名規範。
4. **強制品質閘門（`quality-gate`，未跑完禁止宣告完成）**：
   - 任何程式碼異動後，**必須執行** `powershell -ExecutionPolicy Bypass -File scripts/quality-gate.ps1`，一次通過以下 4 項檢查：
     1. `dotnet build ECCSELECTION.slnx -warnaserror`（0 警告、0 錯誤）
     2. `dotnet format ECCSELECTION.slnx --verify-no-changes --no-restore`
     3. `dotnet test ECCSELECTION.slnx --no-build --verbosity normal --collect:"XPlat Code Coverage"`
     4. `npx --yes ecc-agentshield scan --path . --format text`
   - 若修改涉及 `Views/`、`Controllers/` 或前端 JS，須於 `http://localhost:5109` 實機驗證。
   - **證據輸出契約**：最終回覆必須逐項列出上述 4 項（及 UI 實機驗證）的實測結果，不得只口頭聲稱已檢查。
5. **文件同步**：完成驗證後更新 `DEVELOPMENT_STATUS.md`（與必要時之 `VALIDATION_REPORT_ECCSELECTION.md`）。

## 3. 詳細參考目錄
- 最高規範：`.ecc/rules/project/eccselection-mvc.md`
- 流程指令：`.ecc/commands/`（`plan`, `code-review`, `security-scan`, `quality-gate`, `test-coverage`, `build-fix`）
- 角色檢查清單：`.ecc/agents/`（`csharp-reviewer.md`, `database-reviewer.md`, `tdd-guide.md`, `e2e-runner.md`, `security-reviewer.md`）
- 長期記憶：`AI_MEMORY.md`
